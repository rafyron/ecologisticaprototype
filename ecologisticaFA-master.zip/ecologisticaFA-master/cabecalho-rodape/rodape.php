<div class= "rodape">
     <h3 align = "right">Desenvolvido por Medusa Softworks <img src="../assets/img/icons/logomedusa.png" width="35px"> </h3>
</div>

