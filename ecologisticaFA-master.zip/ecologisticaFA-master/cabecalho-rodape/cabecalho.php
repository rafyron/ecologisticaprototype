<div class="header">
        <img src="./sistema/img-icon/icons/caminhao.png" width="70px">
</div>