<div class="header">
    <h1 align="center">
        <img src="./img-icon/icons/caminhao.png" width="64px">
    </h1>
</div>
