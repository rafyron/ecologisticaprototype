
# Ecologística
### Projeto Desenvolvido para Fatec Aberta 2024

Aplicação WEB destinada a gerenciamento de Frete, onde o usuário poderá controlar os lucros, os custos, e muito mais...

Tecnologias utilizadas no projeto:
- HTML
- CSS
- JS
- PHP + MySQL

*ATENÇÃO: CUIDADO COM A SOBREPOSIÇÃO DE ARQUIVO!*
